package com.example.covidapp;

public class Cases {
    String continent;
    String country;
    int allCases;
    int death;
    int activeCases;
    int recovered;

    public Cases(String continent, String country, int allCases, int death, int activeCases, int recovered) {
        this.continent = continent;
        this.country = country;
        this.allCases = allCases;
        this.death = death;
        this.activeCases = activeCases;
        this.recovered = recovered;
    }

    public String getContinent() {
        return continent;
    }

    public String getCountry() {
        return country;
    }

    public int getAllCases() {
        return allCases;
    }

    public int getDeath() {
        return death;
    }

    public int getActiveCases() {
        return activeCases;
    }

    public int getRecovered() {
        return recovered;
    }

    public void setContinent(String continent) {
        this.continent = continent;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public void setAllCases(int allCases) {
        this.allCases = allCases;
    }

    public void setDeath(int death) {
        this.death = death;
    }

    public void setActiveCases(int activeCases) {
        this.activeCases = activeCases;
    }

    public void setRecovered(int recovered) {
        this.recovered = recovered;
    }
}
