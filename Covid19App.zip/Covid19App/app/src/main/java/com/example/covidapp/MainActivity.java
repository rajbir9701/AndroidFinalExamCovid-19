package com.example.covidapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener, AdapterView.OnItemClickListener{
    ArrayList<Cases> country = new ArrayList<Cases>();
    ArrayList<Cases> selected = new ArrayList<Cases>();
    Spinner spin;
    ListView list;
    public  static  int all,d,r,active;
    public  static String title;
    String[] cntry = {"North America", "South America","Europe","Asia"};

    public void fillData(){
        country.add(new Cases("North America","Canada",40190,2005,24230,13789));
        country.add(new Cases("North America","USA",848779,47230,717456,84723));
        country.add(new Cases("North America","Mexico",10592,970,6947,2627));
        country.add(new Cases("South America","Brazil",40190,2005,24230,13789));
        country.add(new Cases("South America","Peru",40190,2005,24230,13789));
        country.add(new Cases("Europe","UK",133456,18100,115051,22567));
        country.add(new Cases("Europe","France",159315,21340,79880,40657));
        country.add(new Cases("Europe","Germany",150234,5315,99400,45560));
        country.add(new Cases("Europe","Spain",208455,21717,107345,85912));
        country.add(new Cases("Europe","Italy",187652,25085,107668,545376));
        country.add(new Cases("Asia","China",82345,4632,959,77207));
        country.add(new Cases("Asia","Japan",11950,299,10227,1424));
        country.add(new Cases("Asia","India",21370,681,16319,4370));
        country.add(new Cases("Asia","South Korea",10702,240,2051,8233));

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fillData();
        spin = findViewById(R.id.sp);
        list = findViewById(R.id.lv);
        ArrayAdapter ca=new ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cntry);
        ca.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        list.setAdapter(new casesAdapter(this,country));
        spin.setAdapter(ca);
        list.setOnItemClickListener(this);
        spin.setOnItemSelectedListener(this);

    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String c = cntry[i];
        selected.clear();
        for(int j = 0;j<country.size();j++)
            if(c.equals(country.get(j).getContinent()))
               selected.add(country.get(j));
            list.setAdapter(new casesAdapter(this,selected));

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        title = country.get(i).getCountry();
        all = selected.get(i).getAllCases();
        d= selected.get(i).getDeath();
        r =selected.get(i).getRecovered();
        active =selected.get(i).getActiveCases();
        Intent intent = new Intent(this,caseDetails.class);
        startActivity(intent);


    }
}
