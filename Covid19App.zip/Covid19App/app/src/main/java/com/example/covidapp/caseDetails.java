package com.example.covidapp;

import android.os.Bundle;

import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;



import static com.example.covidapp.MainActivity.active;


public class caseDetails  extends AppCompatActivity {
    TextView alcasess,deaths,rec,activecas,titleName;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.casedetails);
      alcasess = findViewById(R.id.tvAll);
        deaths = findViewById(R.id.tvDeath);
        rec = findViewById(R.id.tvRecovered);
        activecas = findViewById(R.id.tvActive);
        titleName = findViewById(R.id.tvTitle);
        alcasess.setText(String.valueOf(MainActivity.all));
       deaths.setText(String.valueOf(MainActivity.d));
        rec.setText(String.valueOf(MainActivity.r));
        activecas.setText(String.valueOf(active));
        titleName.setText(MainActivity.title);


    }

}

