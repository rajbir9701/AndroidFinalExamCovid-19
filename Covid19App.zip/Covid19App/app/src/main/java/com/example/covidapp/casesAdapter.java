package com.example.covidapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class casesAdapter extends BaseAdapter {
   private  ArrayList<Cases> caseData;

    LayoutInflater layoutInflater;
    public casesAdapter(Context context,ArrayList<Cases> caseData){
        this.caseData = caseData;
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return caseData.size();
    }

    @Override
    public Object getItem(int i) {
        return caseData.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder ;
        if(view == null){
            holder = new ViewHolder();
            view = layoutInflater.inflate(R.layout.show,null);

            holder.cname = view.findViewById(R.id.tvCountry);
            holder.allC = view.findViewById(R.id.tvAllCases);
            view.setTag(holder);

        }
        else
            holder = (ViewHolder) view.getTag();
        holder.cname.setText(caseData.get(i).getCountry());
        holder.allC.setText(String.valueOf(caseData.get(i).getAllCases()));
        return view;

    }
    static class ViewHolder{
        TextView cname,allC;

    }
}
